# TWOM Warrior Hub v0.4 — Android

Projeto Android Studio (Kotlin), mínimo Android 8.0 (API 26).

## Abrir e testar
1. Descompacte o ZIP e abra a pasta `TWOMWarriorHub` no Android Studio.
2. Aguarde a sincronização Gradle (necessita Android SDK e acesso aos repositórios Google/Maven).
3. Execute num Android ou emulador Android.
4. Toque em **Abrir Hub flutuante** e conceda a permissão "Mostrar sobre outras apps".
5. Volte à app e toque em **Abrir Hub flutuante** novamente.
6. Abra o TWOM. A Hub pode ser minimizada e arrastada pelo fundo do painel.

## Limitações
- Interface funcional, mas **não é ainda um bot**: Iniciar/Parar altera apenas o estado local, sem gerar toques no jogo.
- Auto Attack, Auto Loot e Auto Move guardam preferências locais.
- O botão de emergência interrompe o estado de simulação.
- A janela poderá ser restringida por políticas de sobreposição de alguns dispositivos.
- Para automação futura, será necessário implementar separadamente captura visual e um serviço de acessibilidade consentido, além de testes e verificações das regras do jogo.
- Não inclui APK compilado: é código-fonte para Android Studio.


## Gerar APK pelo GitHub
Carregue o conteúdo desta pasta (incluindo a pasta oculta `.github`) para a raiz de um repositório GitHub. Em Actions > Gerar APK TWOM Hub > Run workflow, execute a compilação. No final descarregue o artefacto TWOM-Warrior-Hub-APK. É uma compilação debug de teste, não publicada.
